import random

import numpy as np

import pygame
import sys
import math
from player import *
from ai import *
from endgame import *
from random import choices
from copy import deepcopy
import cv2 as cv

ROW_COUNT = 6
COLUMN_COUNT = 7
WINDOW_LENGTH = 4
EMPTY = 0
SQUARESIZE = 100
width = COLUMN_COUNT * SQUARESIZE
height = (ROW_COUNT + 1) * SQUARESIZE
size = (width, height)
RADIUS = int(SQUARESIZE / 2 - 5)

player = Player(0, 1)
ai = AI_Player(1, 2)
test = set()

#################################################################
def drop_piece(board, row, col, piece, rnd=False):
    if rnd:
        print("in expected")
        random_num = random.randint(1, 10)
        print(random_num)
        if col == 0:
            if random_num < 6:
                chosenCOL = col
            else:
                chosenCOL = col + 1
        elif col == 6:
            if random_num < 6:
                chosenCOL = col
            else:
                chosenCOL = col - 1
        elif random_num < 6:
            chosenCOL = col
        elif random_num < 8:
            chosenCOL = col - 1
        else:
            chosenCOL = col + 1
    else:
        chosenCOL = col

    chosenCOL = max(0, min(chosenCOL, len(board[0]) - 1))
    new_row = get_next_open_row(board, chosenCOL)
    if new_row is not None:
        # If a valid row is found, drop the piece
        board[new_row][chosenCOL] = piece
    else:
        # If the column is full, retry the process by calling the function again
        drop_piece(board, row, col, piece, rnd)
    

def drop_piece2(board, row, col, piece, rnd=False):
    if rnd:
        
        random_num = random.randint(1, 10)
        print("in expected"+str(random_num)+ "col:" + str(col))
        if col == 0 and board[row][col + 1] != 0 and random_num > 6:
            chosenCOL = col + 1
            row = get_next_open_row(board, chosenCOL)
            row = row if row is not None and 0 <= row <= 5 else None

        elif col == 6 and board[row][col - 1] != 0 and random_num > 6:
            chosenCOL = col - 1
            row = get_next_open_row(board, chosenCOL)
            row = row if row is not None and 0 <= row <= 5 else None
        elif col == 0 and random_num < 6:
            chosenCOL = col
        elif col == 6 and random_num < 6:
            chosenCOL = col
        elif random_num < 6:
            chosenCOL = col
        elif random_num < 8:
            chosenCOL = col - 1
            row = get_next_open_row(board, chosenCOL)
            row = row if row is not None and 0 <= row <= 5 else None
        else:
            chosenCOL = col + 1
            row = get_next_open_row(board, chosenCOL)
            row = row if row is not None and 0 <= row <= 5 else None
        print("random number: " + str(random_num) + ", chosenCol: " + str(chosenCOL) + ", chosenRow: " + str(row))

    else:
        chosenCOL = col
    chosenCOL = max(0, min(chosenCOL, len(board[0]) - 1))

    # Check if the chosen column is not full
    row = get_next_open_row(board, chosenCOL)

    if row is not None and 0 <= row < len(board) and board[row][chosenCOL] == 0:
    # Your code here
        board[row][chosenCOL] = piece
    else:
        # If the column is full, retry the process by calling the function again
        drop_piece(board, row, col, piece, True)

#places the current move's player ['x'|'o'] in the referenced column in the board
def makeMove(board, col, player):
    #deepcopy is used to take acopy of current board and not affecting the original one
    tempBoard = deepcopy(board)
    for row in range(5,-1,-1):
        if tempBoard[row][col] == ' ':
            tempBoard[row][col] = player
            return tempBoard, row, col
#############################################################

def is_valid_location(board, col):
    return board[ROW_COUNT - 1][col] == 0


def get_next_open_row(board, col):
    for r in range(ROW_COUNT):
        if board[r][col] == 0:
            return r

def generateString(state):
    str = list()
    state = np.flip(state, 0)
    for i in range(0, ROW_COUNT):
        for j in range(0, COLUMN_COUNT):
            str.append(state[i][j])
    return str


def listToString(s):
    s = generateString(s)
    listToStr = ' '.join(map(str, s))
    return listToStr


def print_board(board):
    print(np.flip(board, 0))


# def evaluate_window(window, piece):
#     score = 0
#
#     opp_piece = player.getPiece()  # PLAYER_PIECE
#     if piece == player.getPiece():  # PLAYER_PIECE:
#         opp_piece = ai.getPiece()  # AI_PIECE
#
#     if window.count(piece) == 4:
#         score += 100
#
#     elif window.count(piece) == 3 and window.count(EMPTY) == 1:
#         score += 5
#     elif window.count(piece) == 2 and window.count(EMPTY) == 2:
#         score += 2
#
#     if window.count(opp_piece) == 3 and window.count(EMPTY) == 1:
#         score -= 50
#
#     return score


def evaluate_window(window, piece):
    score = 0

    opp_piece = player.getPiece()  # PLAYER_PIECE
    if piece == player.getPiece():  # PLAYER_PIECE:
        opp_piece = ai.getPiece()  # AI_PIECE

    if window.count(piece) == 4:
        score += 100

    elif window.count(piece) == 3 and window.count(EMPTY) == 1:
        score += 5
    elif window.count(piece) == 2 and window.count(EMPTY) == 2:
        score += 2

    if window.count(opp_piece) == 3 and window.count(EMPTY) == 1:
        score -= 50
    elif window.count(opp_piece) == 4:
        score -= 100

    return score


def calcScore(board, piece):
    # ai.score=0
    # player.score=0
    ## Score Horizontal
    for r in range(ROW_COUNT):
        row_array = [int(i) for i in list(board[r, :])]
        for c in range(COLUMN_COUNT - 3):
            window = row_array[c:c + WINDOW_LENGTH]
            if window.count(piece) == 4:
                if piece == player.getPiece():
                    player.score = player.getScore() + 1
                else:
                    ai.score = ai.getScore() + 1

            ## Score Vertical
    for c in range(COLUMN_COUNT):
        col_array = [int(i) for i in list(board[:, c])]
        for r in range(ROW_COUNT - 3):
            window = col_array[r:r + WINDOW_LENGTH]
            if window.count(piece) == 4:
                if piece == player.getPiece():
                    player.score = player.getScore() + 1
                else:
                    ai.score = ai.getScore() + 1

            ## Score positive sloped diagonal
    for r in range(ROW_COUNT - 3):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r + i][c + i] for i in range(WINDOW_LENGTH)]
            if window.count(piece) == 4:
                if piece == player.getPiece():
                    player.score = player.getScore() + 1
                else:
                    ai.score = ai.getScore() + 1

            ##Score negative sloped diagonals
    for r in range(ROW_COUNT - 3):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r + 3 - i][c + i] for i in range(WINDOW_LENGTH)]
            if window.count(piece) == 4:
                if piece == player.getPiece():
                    player.score = player.getScore() + 1
                else:
                    ai.score = ai.getScore() + 1


def score_position(board, piece):
    score = 0

    # Define the scoring matrix
    scoring_matrix = [[1, 1, 1, 1, 1, 1, 1],
                      [1, 2, 2, 2, 2, 2, 1],
                      [1, 2, 3, 3, 3, 2, 1],
                      [1, 2, 3, 4, 3, 2, 1],
                      [1, 2, 3, 3, 3, 2, 1],
                      [1, 2, 2, 2, 2, 2, 1]]

    ## Score center column
    center_array = [int(i) for i in list(board[:, COLUMN_COUNT // 2])]
    center_count = center_array.count(piece)
    score += center_count * scoring_matrix[3][3]

    ## Score Horizontal
    for r in range(ROW_COUNT):
        row_array = [int(i) for i in list(board[r, :])]
        for c in range(COLUMN_COUNT - 3):
            window = row_array[c:c + WINDOW_LENGTH]
            score += evaluate_window(window, piece) * scoring_matrix[r][c]

    ## Score Vertical
    for c in range(COLUMN_COUNT):
        col_array = [int(i) for i in list(board[:, c])]
        for r in range(ROW_COUNT - 3):
            window = col_array[r:r + WINDOW_LENGTH]
            score += evaluate_window(window, piece) * scoring_matrix[r][c]

    ## Score positive sloped diagonal
    for r in range(ROW_COUNT - 3):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r + i][c + i] for i in range(WINDOW_LENGTH)]
            score += evaluate_window(window, piece) * scoring_matrix[r][c]

    ## Score negative sloped diagonals
    for r in range(ROW_COUNT - 3):
        for c in range(COLUMN_COUNT - 3):
            window = [board[r + 3 - i][c + i] for i in range(WINDOW_LENGTH)]
            score += evaluate_window(window, piece) * scoring_matrix[r][c]

    return score


def is_terminal_node(board):
    return len(get_valid_locations(
        board)) == 0  # or winning_move(board, player.getPiece()) or winning_move(board, ai.getPiece())


def isEndGame(board):
    if len(get_valid_locations(board)) == 0:
        return True
    else:
        return False

###########################################NADAZ
def minimax_withoutpruning_tree(board, depth, maximizingPlayer):
    valid_locations = get_valid_locations(board)
    is_terminal = is_terminal_node(board)
    if depth == 0 or is_terminal:
        if is_terminal:
            return {'value': None, 'move': None, 'children': []}, None
        else:  # Depth is zero
            return {'value': score_position(board, ai.getPiece()), 'move': None, 'children': []}, None

    if maximizingPlayer:
        value = -math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, ai.getPiece())
            child_tree, _ = minimax_withoutpruning_tree(b_copy, depth - 1, False)
            if child_tree['value'] > value:
                value = child_tree['value']
                column = col
            test.add(listToString(b_copy))
        current_tree = {'value': value, 'move': column, 'children': []}
        return current_tree, column

    else:  # Minimizing player
        value = math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, player.getPiece())
            child_tree, _ = minimax_withoutpruning_tree(b_copy, depth - 1, True)
            if child_tree['value'] < value:
                value = child_tree['value']
                column = col
            test.add(listToString(b_copy))
        current_tree = {'value': value, 'move': column, 'children': []}
        return current_tree, column

##############################################
# minimax wihout pruning
def minimax_withoutpruning(board, depth, maximizingPlayer):
    valid_locations = get_valid_locations(board)
    is_terminal = is_terminal_node(board)
    
    if depth == 0 or is_terminal:
        if is_terminal:
            return (None, 0)
        else:  # Depth is zero
            return (None, score_position(board, ai.getPiece()))

    if maximizingPlayer:
        value = -math.inf
        column = random.choice(valid_locations)
        children = []
        
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, ai.getPiece())
            _, new_score = minimax_withoutpruning(b_copy, depth - 1, False)
            
            if new_score > value:
                value = new_score
                column = col
            test.add(listToString(b_copy))
           # print("appended")
            children.append(b_copy)

        # Draw GUI for parent and children
#        print_parent_and_children_gui(board, children)

        return column, value

    else:  # Minimizing player
        value = math.inf
        column = random.choice(valid_locations)
        children = []

        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, player.getPiece())
            _, new_score = minimax_withoutpruning(b_copy, depth - 1, True)

            if new_score < value:
                value = new_score
                column = col
            test.add(listToString(b_copy))
            children.append(b_copy)

        # Draw GUI for parent and children
      #  print_parent_and_children_gui(board, children)

        return column, value


################################################################NADAZ
def minimaxAB(board, depth, alpha, beta, maximizingPlayer):
    is_terminal = is_terminal_node(board)
    
    if depth == 0 or is_terminal:
        if is_terminal:
            return (None, 0)
        else:  # Depth is zero
            return (None, score_position(board, ai.getPiece()))
    
    if maximizingPlayer:
        return maximize_alpha_beta(board, depth, alpha, beta, ai, player)
    else:
        return minimize_alpha_beta(board, depth, alpha, beta, player, ai)

def maximize_alpha_beta(board, depth, alpha, beta, curr_player, opponent):
    valid_locations = get_valid_locations(board)
    best_move = valid_locations[0]
    value = float("-inf")

    for col in valid_locations:
        row = get_next_open_row(board, col)
        b_copy = board.copy()
        drop_piece(b_copy, row, col, curr_player.getPiece())
        new_score = minimax(b_copy, depth - 1, alpha, beta, opponent)[1]

        if new_score > value:
            value = new_score
            best_move = col

        alpha = max(alpha, value)

        if alpha >= beta:
            break
        test.add(listToString(b_copy))
    return best_move, value

def minimize_alpha_beta(board, depth, alpha, beta, curr_player, opponent):
    valid_locations = get_valid_locations(board)
    best_move = valid_locations[0]
    value = float("inf")

    for col in valid_locations:
        row = get_next_open_row(board, col)
        b_copy = board.copy()
        drop_piece(b_copy, row, col, curr_player.getPiece())
        new_score = minimax(b_copy, depth - 1, alpha, beta, opponent)[1]

        if new_score < value:
            value = new_score
            best_move = col

        beta = min(beta, value)

        if alpha >= beta:
            break
        test.add(listToString(b_copy))
    return best_move, value

def minimaxExpeccti(board,depth,maximizingPlayer):
    valid_moves = get_valid_locations(board)

    # Use probabilities for choosing columns
    probabilities = [0.2, 0.6, 0.2]
    is_terminal = is_terminal_node(board)

    is_terminal = is_terminal_node(board)
    if depth == 0 or is_terminal:
        if is_terminal:
            return (None, 0)
        else:  # Depth is zero
            return (None, score_position(board, ai.getPiece()))
        
    
    if maximizingPlayer:
        value = float("-inf")
        column = random.choice(valid_moves)
        for col in valid_moves:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, ai.getPiece(), True)
            new_score = minimaxExpeccti(b_copy, depth - 1, False)[1]
            value = max(value, new_score)
            column = col if new_score == value else column
        test.add(listToString(b_copy))
        return column, value

    else:  # Chance node (average the scores with probabilities)
        value = 0
        column = random.choice(valid_moves)
        for col in valid_moves:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, player.getPiece(), True)
            new_score = minimaxExpeccti(b_copy, depth - 1, True)[1]
            value += new_score * probabilities[col]
        test.add(listToString(b_copy))
        return column, value
    


#############################################################################  
# minimax with pruning
def minimax(board, depth, alpha, beta, maximizingPlayer):
    valid_locations = get_valid_locations(board)
    is_terminal = is_terminal_node(board)
    if depth == 0 or is_terminal:
        if is_terminal:
            return (None, 0)
        else:  # Depth is zero
            return (None, score_position(board, ai.getPiece()))
    if maximizingPlayer:
        value = -math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, ai.getPiece())
            new_score = minimax(b_copy, depth - 1, alpha, beta, False)[1]
            if new_score > value:
                value = new_score
                column = col
            test.add(listToString(b_copy))
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return column, value

    else:  # Minimizing player
        value = math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, player.getPiece())
            new_score = minimax(b_copy, depth - 1, alpha, beta, True)[1]
            if new_score < value:
                value = new_score
                column = col
            beta = min(beta, value)
            test.add(listToString(b_copy))
            if alpha >= beta:
                break
        return column, value


def get_valid_locations(board):
    valid_locations = []
    for col in range(COLUMN_COUNT):
        if is_valid_location(board, col):
            valid_locations.append(col)
    return valid_locations


def pick_best_move(board, piece):
    valid_locations = get_valid_locations(board)
    best_score = -10000
    best_col = random.choice(valid_locations)
    for col in valid_locations:
        row = get_next_open_row(board, col)
        temp_board = board.copy()
        drop_piece(temp_board, row, col, piece)
        score = score_position(temp_board, piece)
        if score > best_score:
            best_score = score
            best_col = col

    return best_col
#####################################################NadaZ
visited_states = {}

def minimaxHASHING(board, depth, maximizingPlayer):
    global visited_states  # Declare the hash map as global

    valid_locations = get_valid_locations(board)
    is_terminal = is_terminal_node(board)
    board_key = tuple(map(tuple, board))  # Convert the board to a hashable key

    # Check if the state has been visited before
    if board_key in visited_states:
        return visited_states[board_key]

    if depth == 0 or is_terminal:
        if is_terminal:
            return (None, 0)
        else:  # Depth is zero
            score = score_position(board, ai.getPiece())
            result = (None, score)
            visited_states[board_key] = result
            return result

    if maximizingPlayer:
        value = -math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, ai.getPiece())
            new_score = minimax(b_copy, depth - 1, False)[1]
            if new_score > value:
                value = new_score
                column = col

        result = (column, value)
        visited_states[board_key] = result
        return result

    else:  # Minimizing player
        value = math.inf
        column = random.choice(valid_locations)
        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = board.copy()
            drop_piece(b_copy, row, col, player.getPiece())
            new_score = minimax(b_copy, depth - 1, True)[1]
            if new_score < value:
                value = new_score
                column = col

        result = (column, value)
        visited_states[board_key] = result
        return result
#################################################NADAZ
import tkinter as tk
from tkinter import Canvas, Frame
import random
import math

class Node:
    def __init__(self, value, depth, maximizing_player,board):
        self.value = value
        self.depth = depth
        self.maximizing_player = maximizing_player
        self.children = []
        self.board = board

def draw_tree(canvas, node, x, y, dx, dy):
    if node is not None:
        canvas.create_oval(x-20, y-20, x+20, y+20, fill="white")
        canvas.create_text(x, y, text=str(node.value))

        if node.children:
            next_x = x - dx
            next_y = y + dy
            for child in node.children:
                canvas.create_line(x, y, next_x, next_y, arrow=tk.LAST)
                draw_tree(canvas, child, next_x, next_y, dx / 2, dy)

def print_parent_and_children_gui(parent_board, children_nodes):
    root = tk.Tk()
    root.title("Minimax Tree GUI")

    parent_frame = Frame(root)
    parent_frame.pack(side=tk.LEFT, padx=20)

    canvas_parent = Canvas(parent_frame, width=200, height=100)
    canvas_parent.pack()
    canvas_parent.create_text(100, 50, text="Parent Board", fill="black")

    for row_index, row in enumerate(parent_board):
        for col_index, cell in enumerate(row):
            canvas_parent.create_text(col_index * 20 + 10, row_index * 20 + 70, text=str(cell), fill="black")

    children_frame = Frame(root)
    children_frame.pack(side=tk.RIGHT, padx=20)

    for i, child_node in enumerate(children_nodes):
        canvas_child = Canvas(children_frame, width=200, height=100)
        canvas_child.grid(row=i, column=0)
        canvas_child.create_text(100, 50, text=f"Child {i+1} Board", fill="black")

        for row_index, row in enumerate(child_node.board):
            for col_index, cell in enumerate(row):
                canvas_child.create_text(col_index * 20 + 10, row_index * 20 + 70, text=str(cell), fill="black")

    root.mainloop()
import copy

def minimax_without_pruning(board, depth, maximizingPlayer):
    valid_locations = get_valid_locations(board)
    is_terminal = is_terminal_node(board)

    if depth == 0 or is_terminal:
        if is_terminal:
            return (None, 0)
        else:  # Depth is zero
            return (None, score_position(board, ai.getPiece()))

    if maximizingPlayer:
        value = -math.inf
        column = random.choice(valid_locations)
        children = []

        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = copy.deepcopy(board)
            drop_piece(b_copy, row, col, ai.getPiece())
            _, new_score = minimax_without_pruning(b_copy, depth - 1, False)

            if new_score > value:
                value = new_score
                column = col
            test.add(listToString(b_copy))
            children.append(Node(new_score, depth-1, False, b_copy))

        # Draw GUI for parent and children
      #  print_parent_and_children_gui(board, children)

        return column, value

    else:  # Minimizing player
        value = math.inf
        column = random.choice(valid_locations)
        children = []

        for col in valid_locations:
            row = get_next_open_row(board, col)
            b_copy = copy.deepcopy(board)
            drop_piece(b_copy, row, col, player.getPiece())
            _, new_score = minimax_without_pruning(b_copy, depth - 1, True)

            if new_score < value:
                value = new_score
                column = col
            test.add(listToString(b_copy))
            children.append(Node(new_score, depth-1, True, b_copy))

        # Draw GUI for parent and children
       # print_parent_and_children_gui(board, children)

        return column, value

# Your other functions (get_valid_locations, is_terminal_node, score_position, get_next_open_row, drop_piece) go here

class MinimaxTreeGUI(Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        self.canvas = Canvas(self, width=600, height=400)
        self.canvas.pack()
        self.draw_example_tree()

    def draw_example_tree(self):
        root = Node(0, 3, True, None)  # Example root node
        draw_tree(self.canvas, root, 300, 50, 150, 100)



