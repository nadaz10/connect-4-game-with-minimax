from tkinter import *
from PIL import ImageTk, Image
from PIL import ImageTk, Image
import tkinter.font as tkFont


def play_again(event):
  new_window.destroy()
  import connect4

def quit(event):
  new_window.destroy()


def display_scores(ai_score, player_score):
  # Create a new window
  global new_window
  new_window=Tk()
  new_window.title("Game Over")
  new_window.geometry("700x700")

  # Load the image
  image = ImageTk.PhotoImage(Image.open("ending2.png"))
  label = Label(new_window, image=image)
  label.place(relx=0.5, rely=0.5, anchor='center')  # Center the image
  label.pack()

  # Determine the winner
  winner = "AI" if ai_score > player_score else "Player"

  # Write the scores and winner on the image

  # scores_text = f"{winner} wins!\nAI Score: {ai_score}\nPlayer Score: {player_score}"
  # scores_text_widget = Text(new_window, bg='white')  # Create a Text widget with a white background
  # scores_text_widget.insert(END, scores_text)  # Insert the scores and winner into the Text widget
  # scores_text_widget.grid(row=0,column=0)

  # Create a label for the input field
  fontStyle = tkFont.Font(family="Helvetica", size=40, weight="bold")
  label2 = Label(new_window, text=winner, fg="yellow", font=fontStyle)
  label2.place(relx=0.45, rely=0.45, anchor='center')


  fontStyle2 = tkFont.Font(family="Helvetica", size=25, weight="bold")
  label3 = Label(new_window, text="AI: {0}                 Player: {1}".format(ai_score, player_score), fg="red", font=fontStyle)
  label3.place(relx=0.47, rely=0.67, anchor='center')


  # Load the smaller images
  image4 = ImageTk.PhotoImage(Image.open("playagain.png"))
  image5 = ImageTk.PhotoImage(Image.open("quit.png"))

  # Create labels for the smaller images
  label4 = Label(new_window, image=image4, borderwidth=0, highlightthickness=0)
  label5 = Label(new_window, image=image5, borderwidth=0, highlightthickness=0)

  # Place the labels at specific locations and bind the Button-1 event to them
  label4.place(relx=0.5, rely=0.78, anchor='center')
  label4.bind("<Button-1>", play_again)

  label5.place(relx=0.5, rely=0.9, anchor='center')
  label5.bind("<Button-1>", quit)



  # Start the event loop for the new window
  new_window.mainloop()

