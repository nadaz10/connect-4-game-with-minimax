from game import draw_board
from draw import draw_piece

def draw_board_to_image(board, img):
   # Draw the board on the image
   for i in range(len(board)):
       for j in range(len(board[0])):
           if board[i][j] == 1:
               draw_piece(img, i, j, 1)
           elif board[i][j] == 2:
               draw_piece(img, i, j, 2)
   return img
