from cv2 import MAT_MAGIC_VAL, WINDOW_AUTOSIZE, namedWindow
import cv2


def scroll(img):
    largeImage = namedWindow(img, WINDOW_AUTOSIZE)

    cv2.waitKey(0)

    winH = 300
    winW = 600
    if winH >= largeImage.rows:
        winH = largeImage.rows - 1
    if winW >= largeImage.cols:
        winW = largeImage.cols - 1

    scrolHight = 0
    scrolWidth = 0
    cv2.cvCreateTrackbar("Hscroll", "controlWin", scrolHight, (largeImage.rows - winH))
    cv2.cvCreateTrackbar("Wscroll", "controlWin", scrolWidth, (largeImage.cols - winW))
    while cv2.waitKey(0) != 'q':
        winImage = largeImage(cv2.Rect(scrolWidth, scrolHight, winW, winH))
        cv2.imshow("winImage", winImage)
