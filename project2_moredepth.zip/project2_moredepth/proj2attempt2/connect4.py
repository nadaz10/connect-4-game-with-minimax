

from game import *

from tkinter import *
from PIL import ImageTk, Image
import tkinter.font as tkFont
from tkinter import messagebox


new_window = None # Define new_window as a global variable

def minimax(event):
   global new_window # Use the global variable new_window
   root.destroy()
   #new_window.destroy() # Add this line to close the new window
   game(0,x)
   #print("Function 1 called")

def alphabeta(event):
   global new_window # Use the global variable new_window
   root.destroy()
   #new_window.destroy() # Add this line to close the new window
   game(1,x)
   #print("Function 2 called")

def expected(event):
   global new_window # Use the global variable new_window
   root.destroy()
   #new_window.destroy() # Add this line to close the new window
   game(2,x)
   #print("Function 3 called")

# Create the main window
root = Tk()
root.title("Connect4!")
root.geometry("700x700")

# Load the image
image = ImageTk.PhotoImage(Image.open("connect4(1).jpeg"))
label = Label(root, image=image)
label.place(relx=0.5, rely=0.5, anchor='center') # Center the image

# Create a label for the input field
fontStyle = tkFont.Font(family="Helvetica", size=10, weight="bold")
label = Label(root, text="ENTER DEPTH", fg="red", font=fontStyle)
label.place(relx=0.45, rely=0.65, anchor='center') # Position the label above the input field

# Create an input field
input_field = Entry(root, font=("monospace", 10))
input_field.place(relx=0.6, rely=0.65, anchor='center', width=70, height=30) # Bigger input field

# Create a button that opens a new window and closes the original one
def open_new_window():
 global new_window # Use the global variable new_window
 global x
 x = int(input_field.get())
 if not x:
     messagebox.showerror(title="Error", message="Please enter depth")
 else:
     new_window = Toplevel(root)
     new_window.title("Choose Game Type")
     new_window.geometry("700x700")


     # Load the image for the second page
     image2 = ImageTk.PhotoImage(Image.open("connect4(2).png"))
     label2 = Label(new_window, image=image2)
     label2.place(relx=0.5, rely=0.5, anchor='center') # Center the image

     # Load the smaller images
     image3 = ImageTk.PhotoImage(Image.open("minimax.png"))
     image4 = ImageTk.PhotoImage(Image.open("alphabeta.png"))
     image5 = ImageTk.PhotoImage(Image.open("expected.png"))

     # Create labels for the smaller images
     label3 = Label(new_window, image=image3, borderwidth=0, highlightthickness=0)
     label4 = Label(new_window, image=image4, borderwidth=0, highlightthickness=0)
     label5 = Label(new_window, image=image5, borderwidth=0, highlightthickness=0)

     # Place the labels at specific locations and bind the Button-1 event to them
     label3.place(relx=0.45, rely=0.7, anchor='center')
     label3.bind("<Button-1>", minimax)

     label4.place(relx=0.45, rely=0.8, anchor='center')
     label4.bind("<Button-1>", alphabeta)

     label5.place(relx=0.45, rely=0.9, anchor='center')
     label5.bind("<Button-1>", expected)

     # Start the event loop for the second window
     new_window.mainloop()

     # Destroy the main window after the second window is closed
     try:
         root.destroy()
     except TclError:
         pass


button = Button(root, text="START", command=open_new_window, width=20, height=2, bg="blue", font=fontStyle) # Bigger button with blue background and bold font
button.place(relx=0.52, rely=0.7, anchor='center') # Position the button below the input field

# Start the event loop for the main window
root.mainloop()
